<!-- END theme-panel -->
<!-- BEGIN btn-scroll-top -->
<a href="#" data-toggle="scroll-to-top" class="btn-scroll-top fade"><i class="fa fa-arrow-up"></i></a>
<!-- END btn-scroll-top -->
</div>
<!-- END #app -->

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

<!-- ================== BEGIN core-js ================== -->
<script data-cfasync="false" src="./cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
<script src="{{ asset('admin/assets/js/vendor.min.js ')}}" type="a6be0a9a4afc030152a2c45b-text/javascript "></script>
<script src="{{ asset('admin/assets/js/app.min.js ')}}" type="a6be0a9a4afc030152a2c45b-text/javascript"></script>
<!-- ================== END core-js ================== -->

<!-- ================== BEGIN page-js ================== -->
<script src="{{ asset('admin/assets/plugins/jvectormap-next/jquery-jvectormap.min.js')}}" type="a6be0a9a4afc030152a2c45b-text/javascript"></script>
<script src="{{ asset('admin/assets/plugins/jvectormap-content/world-mill.js')}}" type="a6be0a9a4afc030152a2c45b-text/javascript"></script>
<script src="{{ asset('admin/assets/plugins/apexcharts/dist/apexcharts.min.js')}}" type="a6be0a9a4afc030152a2c45b-text/javascript"></script>
<script src="{{ asset('admin/assets/plugins/moment/min/moment.min.js')}}" type="a6be0a9a4afc030152a2c45b-text/javascript"></script>
<script src="{{ asset('admin/assets/plugins/bootstrap-daterangepicker/daterangepicker.js')}}" type="a6be0a9a4afc030152a2c45b-text/javascript"></script>
<script src="{{ asset('admin/assets/js/demo/dashboard.demo.js')}}" type="a6be0a9a4afc030152a2c45b-text/javascript"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<!-- ================== END page-js ================== -->


<script async src="https://www.googletagmanager.com/gtag/js?id=G-Y3Q0VGQKY3" type="a6be0a9a4afc030152a2c45b-text/javascript"></script>
<script type="a6be0a9a4afc030152a2c45b-text/javascript">

</script>
<script src="./cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="a6be0a9a4afc030152a2c45b-|49" defer></script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"rayId":"926c5eed0ec39191","version":"2025.1.0","r":1,"serverTiming":{"name":{"cfExtPri":true,"cfL4":true,"cfSpeedBrain":true,"cfCacheStatus":true}},"token":"4db8c6ef997743fda032d4f73cfeff63","b":1}' crossorigin="anonymous"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-HO3dJGyz6cC6B/..." crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<script type="a6be0a9a4afc030152a2c45b-text/javascript">
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'G-Y3Q0VGQKY3');
</script>
<style>
.app-sidebar.show-left{
	left:0px;
	z-index: 999999;
}
.mobile_menuw{
	display:none;		
}
@media (min-width:100px) and (max-width:767px){
.mobile_menuw{
	display:block;	
	font-size:24px;
	z-index: 999999;
}
.menu-header {
	display: flex;
	justify-content: space-between;
	align-items: center;
}
.overlay_menu.showover {
    position: fixed;
    top: 0px;
    left: 0px;
    background: rgba(00, 00, 00, 0.5);
    width: 100%;
    height: 100%;
    z-index: 9999;
}
.app-header .brand .brand-logo{
	padding:0px;
	display:block !important;
}  
}
</style>
<script>
$(document).ready(function(){
	$(".menu-toggler").click(function(){
		$(".app-sidebar").toggleClass("show-left");
		$(".overlay_menu").toggleClass("showover");
	});
	$(".mobile_menuw").click(function(){
		$(".app-sidebar").removeClass("show-left");
		$(".overlay_menu").removeClass("showover");
	});
	$(".overlay_menu").click(function(){
		$(".app-sidebar").removeClass("show-left"); 
		$(".overlay_menu").removeClass("showover");
	});
	
});
</script>
<script>
    ! function() {
        "use strict";

        function e(e) {
            try {
                if ("undefined" == typeof console) return;
                "error" in console ? console.error(e) : console.log(e)
            } catch (e) {}
        }

        function t(e) {
            return d.innerHTML = '<a href="' + e.replace(/"/g, "&quot;") + '"></a>', d.childNodes[0].getAttribute("href") || ""
        }

        function r(e, t) {
            var r = e.substr(t, 2);
            return parseInt(r, 16)
        }

        function n(n, c) {
            for (var o = "", a = r(n, c), i = c + 2; i < n.length; i += 2) {
                var l = r(n, i) ^ a;
                o += String.fromCharCode(l)
            }
            try {
                o = decodeURIComponent(escape(o))
            } catch (u) {
                e(u)
            }
            return t(o)
        }

        function c(t) {
            for (var r = t.querySelectorAll("a"), c = 0; c < r.length; c++) try {
                var o = r[c],
                    a = o.href.indexOf(l);
                a > -1 && (o.href = "mailto:" + n(o.href, a + l.length))
            } catch (i) {
                e(i)
            }
        }

        function o(t) {
            for (var r = t.querySelectorAll(u), c = 0; c < r.length; c++) try {
                var o = r[c],
                    a = o.parentNode,
                    i = o.getAttribute(f);
                if (i) {
                    var l = n(i, 0),
                        d = document.createTextNode(l);
                    a.replaceChild(d, o)
                }
            } catch (h) {
                e(h)
            }
        }

        function a(t) {
            for (var r = t.querySelectorAll("template"), n = 0; n < r.length; n++) try {
                i(r[n].content)
            } catch (c) {
                e(c)
            }
        }

        function i(t) {
            try {
                c(t), o(t), a(t)
            } catch (r) {
                e(r)
            }
        }
        var l = "/cdn-cgi/l/email-protection#",
            u = ".__cf_email__",
            f = "data-cfemail",
            d = document.createElement("div");
        i(document),
            function() {
                var e = document.currentScript || document.scripts[document.scripts.length - 1];
                e.parentNode.removeChild(e)
            }()
    }();
</script>


<script>
    ! function() {
        "use strict";

        function t() {
            return "cf-marker-" + Math.random().toString().slice(2)
        }

        function e() {
            for (var t = [], e = 0; e < arguments.length; e++) t[e] = arguments[e];
            (n = console.warn || console.log).call.apply(n, [console, "[ROCKET LOADER] "].concat(t));
            var n
        }

        function n(t, e) {
            var n = e.parentNode;
            n && h(t, n, e)
        }

        function r(t, e) {
            h(t, e, e.childNodes[0])
        }

        function o(t) {
            var e = t.parentNode;
            e && e.removeChild(t)
        }

        function i(t) {
            var e = t.namespaceURI === A ? "xlink:href" : "src";
            return t.getAttribute(e)
        }

        function a(t, e) {
            var n = t.type.substr(e.length);
            return !(n && !E[n.trim()]) && ((!k || !t.hasAttribute("nomodule")) && !(!k && "module" === n))
        }

        function c(t) {
            return a(t, "")
        }

        function s(t, e) {
            return function(n) {
                if (e(), t) return t.call(this, n)
            }
        }

        function u(t, e) {
            t.onload = s(t.onload, e), t.onerror = s(t.onerror, e)
        }

        function p(t) {
            var e = document.createElementNS(t.namespaceURI, "script");
            e.async = t.hasAttribute("async"), e.textContent = t.textContent;
            for (var n = 0; n < t.attributes.length; n++) {
                var r = t.attributes[n];
                try {
                    r.namespaceURI ? e.setAttributeNS(r.namespaceURI, r.name, r.value) : e.setAttribute(r.name, r.value)
                } catch (o) {}
            }
            return e
        }

        function l(t, e) {
            var n = new I(e);
            t.dispatchEvent(n)
        }

        function d(e) {
            var n = e.namespaceURI === A,
                r = t();
            e.setAttribute(r, "");
            var i = n ? "<svg>" + e.outerHTML + "</svg>" : e.outerHTML;
            L.call(document, i);
            var a = document.querySelector("[" + r + "]");
            if (a) {
                a.removeAttribute(r);
                var c = n && a.parentNode;
                c && o(c)
            }
            return a
        }

        function f(t) {
            if (t && "handleEvent" in t) {
                var e = t.handleEvent;
                return "function" == typeof e ? e.bind(t) : e
            }
            return t
        }

        function h(t, e, n) {
            var r = n ? function(t) {
                return e.insertBefore(t, n)
            } : function(t) {
                return e.appendChild(t)
            };
            Array.prototype.slice.call(t).forEach(r)
        }

        function v() {
            return /chrome/i.test(navigator.userAgent) && /google/i.test(navigator.vendor)
        }

        function y(t, e) {
            function n() {
                this.constructor = t
            }
            H(t, e), t.prototype = null === e ? Object.create(e) : (n.prototype = e.prototype, new n)
        }

        function m(t) {
            return t instanceof Window ? ["load"] : t instanceof Document ? ["DOMContentLoaded", "readystatechange"] : []
        }

        function b(t) {
            var e = t.getAttribute(R);
            if (!e) return null;
            var n = e.split(T);
            return {
                nonce: n[0],
                handlerPrefixLength: +n[1],
                bailout: !t.hasAttribute("defer")
            }
        }

        function g(t) {
            var e = B + t.nonce;
            Array.prototype.forEach.call(document.querySelectorAll("[" + e + "]"), function(n) {
                n.removeAttribute(e), Array.prototype.forEach.call(n.attributes, function(e) {
                    /^on/.test(e.name) && "function" != typeof n[e.name] && n.setAttribute(e.name, e.value.substring(t.handlerPrefixLength))
                })
            })
        }

        function S() {
            var t = window;
            "undefined" != typeof Promise && (t.__cfQR = {
                done: new Promise(function(t) {
                    return U = t
                })
            })
        }

        function w(t) {
            var e = new N(t),
                n = new C(e);
            e.harvestScriptsInDocument(), new W(e, {
                nonce: t,
                blocking: !0,
                docWriteSimulator: n,
                callback: function() {}
            }).run()
        }

        function x(t) {
            var e = new N(t),
                n = new C(e);
            e.harvestScriptsInDocument();
            var r = new W(e, {
                nonce: t,
                blocking: !1,
                docWriteSimulator: n,
                callback: function() {
                    window.__cfRLUnblockHandlers = !0, r.removePreloadHints(), P(t)
                }
            });
            r.insertPreloadHints(), M.runOnLoad(function() {
                r.run()
            })
        }

        function P(t) {
            var e = new O(t);
            M.simulateStateBeforeDeferScriptsActivation(), e.harvestDeferScriptsInDocument(), new W(e, {
                nonce: t,
                blocking: !1,
                callback: function() {
                    M.simulateStateAfterDeferScriptsActivation(), U && U()
                }
            }).run()
        }
        var A = "http://www.w3.org/2000/svg",
            E = {
                "application/ecmascript": !0,
                "application/javascript": !0,
                "application/x-ecmascript": !0,
                "application/x-javascript": !0,
                "text/ecmascript": !0,
                "text/javascript": !0,
                "text/javascript1.0": !0,
                "text/javascript1.1": !0,
                "text/javascript1.2": !0,
                "text/javascript1.3": !0,
                "text/javascript1.4": !0,
                "text/javascript1.5": !0,
                "text/jscript": !0,
                "text/livescript": !0,
                "text/x-ecmascript": !0,
                "text/x-javascript": !0,
                module: !0
            },
            k = void 0 !== document.createElement("script").noModule,
            I = function() {
                var t = window;
                return t.__rocketLoaderEventCtor || Object.defineProperty(t, "__rocketLoaderEventCtor", {
                    value: Event
                }), t.__rocketLoaderEventCtor
            }(),
            L = document.write,
            _ = document.writeln,
            H = Object.setPrototypeOf || {
                __proto__: []
            }
        instanceof Array && function(t, e) {
            t.__proto__ = e
        } || function(t, e) {
            for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n])
        }, D = function() {
            function t(t) {
                this.nonce = t, this.items = []
            }
            return Object.defineProperty(t.prototype, "hasItems", {
                get: function() {
                    return this.items.length > 0
                },
                enumerable: !0,
                configurable: !0
            }), t.prototype.pop = function() {
                return this.items.pop()
            }, t.prototype.forEach = function(t) {
                this.items.forEach(function(e) {
                    var n = e.script;
                    return t(n)
                })
            }, t.prototype.harvestScripts = function(t, e) {
                var n = this,
                    r = e.filter,
                    o = e.mutate;
                Array.prototype.slice.call(t.querySelectorAll("script")).filter(r).reverse().forEach(function(t) {
                    o(t), n.pushScriptOnStack(t)
                })
            }, t.prototype.pushScriptOnStack = function(t) {
                var e = t.parentNode,
                    n = this.createPlaceholder(t),
                    r = !!i(t);
                e.replaceChild(n, t), this.items.push({
                    script: t,
                    placeholder: n,
                    external: r,
                    async: r && t.hasAttribute("async"),
                    executable: c(t)
                })
            }, t.prototype.hasNonce = function(t) {
                return 0 === (t.getAttribute("type") || "").indexOf(this.nonce)
            }, t.prototype.removeNonce = function(t) {
                t.type = t.type.substr(this.nonce.length)
            }, t.prototype.makeNonExecutable = function(t) {
                t.type = this.nonce + t.type
            }, t.prototype.isPendingDeferScript = function(t) {
                return t.hasAttribute("defer") || t.type === this.nonce + "module" && !t.hasAttribute("async")
            }, t
        }(), N = function(t) {
            function e() {
                return null !== t && t.apply(this, arguments) || this
            }
            return y(e, t), e.prototype.harvestScriptsInDocument = function() {
                var t = this;
                this.harvestScripts(document, {
                    filter: function(e) {
                        return t.hasNonce(e)
                    },
                    mutate: function(e) {
                        t.isPendingDeferScript(e) || t.removeNonce(e)
                    }
                })
            }, e.prototype.harvestScriptsAfterDocWrite = function(t) {
                var e = this;
                this.harvestScripts(t, {
                    filter: c,
                    mutate: function(t) {
                        e.isPendingDeferScript(t) && e.makeNonExecutable(t)
                    }
                })
            }, e.prototype.createPlaceholder = function(t) {
                return document.createComment(t.outerHTML)
            }, e
        }(D), O = function(t) {
            function e() {
                return null !== t && t.apply(this, arguments) || this
            }
            return y(e, t), e.prototype.harvestDeferScriptsInDocument = function() {
                var t = this;
                this.harvestScripts(document, {
                    filter: function(e) {
                        return t.hasNonce(e) && t.isPendingDeferScript(e)
                    },
                    mutate: function(e) {
                        return t.removeNonce(e)
                    }
                })
            }, e.prototype.createPlaceholder = function(t) {
                var e = p(t);
                return this.makeNonExecutable(e), e
            }, e
        }(D), C = function() {
            function t(t) {
                this.scriptStack = t
            }
            return t.prototype.enable = function(t) {
                var e = this;
                this.insertionPointMarker = t, this.buffer = "", document.write = function() {
                    for (var t = [], n = 0; n < arguments.length; n++) t[n] = arguments[n];
                    return e.write(t, !1)
                }, document.writeln = function() {
                    for (var t = [], n = 0; n < arguments.length; n++) t[n] = arguments[n];
                    return e.write(t, !0)
                }
            }, t.prototype.flushWrittenContentAndDisable = function() {
                document.write = L, document.writeln = _, this.buffer.length && (document.contains(this.insertionPointMarker) ? this.insertionPointMarker.parentNode === document.head ? this.insertContentInHead() : this.insertContentInBody() : e("Insertion point marker for document.write was detached from document:", "Markup will not be inserted"))
            }, t.prototype.insertContentInHead = function() {
                var t = new DOMParser,
                    e = "<!DOCTYPE html><head>" + this.buffer + "</head>",
                    o = t.parseFromString(e, "text/html");
                if (this.scriptStack.harvestScriptsAfterDocWrite(o), n(o.head.childNodes, this.insertionPointMarker), o.body.childNodes.length) {
                    for (var i = Array.prototype.slice.call(o.body.childNodes), a = this.insertionPointMarker.nextSibling; a;) i.push(a), a = a.nextSibling;
                    document.body || L.call(document, "<body>"), r(i, document.body)
                }
            }, t.prototype.insertContentInBody = function() {
                var t = this.insertionPointMarker.parentElement,
                    e = document.createElement(t.tagName);
                e.innerHTML = this.buffer, this.scriptStack.harvestScriptsAfterDocWrite(e), n(e.childNodes, this.insertionPointMarker)
            }, t.prototype.write = function(t, e) {
                var n = document.currentScript;
                n && i(n) && n.hasAttribute("async") ? (r = e ? _ : L).call.apply(r, [document].concat(t)) : this.buffer += t.map(String).join(e ? "\n" : "");
                var r
            }, t
        }(), j = function() {
            function t() {
                var t = this;
                this.simulatedReadyState = "loading", this.bypassEventsInProxies = !1, this.nativeWindowAddEventListener = window.addEventListener;
                try {
                    Object.defineProperty(document, "readyState", {
                        get: function() {
                            return t.simulatedReadyState
                        }
                    })
                } catch (e) {}
                this.setupEventListenerProxy(), this.updateInlineHandlers()
            }
            return t.prototype.runOnLoad = function(t) {
                var e = this;
                this.nativeWindowAddEventListener.call(window, "load", function(n) {
                    if (!e.bypassEventsInProxies) return t(n)
                })
            }, t.prototype.updateInlineHandlers = function() {
                this.proxyInlineHandler(document, "onreadystatechange"), this.proxyInlineHandler(window, "onload"), document.body && this.proxyInlineHandler(document.body, "onload")
            }, t.prototype.simulateStateBeforeDeferScriptsActivation = function() {
                this.bypassEventsInProxies = !0, this.simulatedReadyState = "interactive", l(document, "readystatechange"), this.bypassEventsInProxies = !1
            }, t.prototype.simulateStateAfterDeferScriptsActivation = function() {
                var t = this;
                this.bypassEventsInProxies = !0, l(document, "DOMContentLoaded"), this.simulatedReadyState = "complete", l(document, "readystatechange"), l(window, "load"), this.bypassEventsInProxies = !1, window.setTimeout(function() {
                    return t.bypassEventsInProxies = !0
                }, 0)
            }, t.prototype.setupEventListenerProxy = function() {
                var t = this;
                ("undefined" != typeof EventTarget ? [EventTarget.prototype] : [Node.prototype, Window.prototype]).forEach(function(e) {
                    return t.patchEventTargetMethods(e)
                })
            }, t.prototype.patchEventTargetMethods = function(t) {
                var e = this,
                    n = t.addEventListener,
                    r = t.removeEventListener;
                t.addEventListener = function(t, r) {
                    for (var o = [], i = 2; i < arguments.length; i++) o[i - 2] = arguments[i];
                    var a = m(this),
                        c = r && r.__rocketLoaderProxiedHandler;
                    if (!c) {
                        var s = f(r);
                        "function" == typeof s ? (c = function(n) {
                            if (e.bypassEventsInProxies || a.indexOf(t) < 0) return s.call(this, n)
                        }, Object.defineProperty(r, "__rocketLoaderProxiedHandler", {
                            value: c
                        })) : c = r
                    }
                    n.call.apply(n, [this, t, c].concat(o))
                }, t.removeEventListener = function(t, e) {
                    for (var n = [], o = 2; o < arguments.length; o++) n[o - 2] = arguments[o];
                    var i = e && e.__rocketLoaderProxiedHandler || e;
                    r.call.apply(r, [this, t, i].concat(n))
                }
            }, t.prototype.proxyInlineHandler = function(t, e) {
                try {
                    var n = t[e];
                    if (n && !n.__rocketLoaderInlineHandlerProxy) {
                        var r = this;
                        t[e] = function(t) {
                            if (r.bypassEventsInProxies) return n.call(this, t)
                        }, Object.defineProperty(t[e], "__rocketLoaderInlineHandlerProxy", {
                            value: !0
                        })
                    }
                } catch (o) {
                    return void console.warn("encountered an error when accessing " + e + " handler:", o.message)
                }
            }, t
        }(), M = function() {
            var t = window;
            return t.__rocketLoaderLoadProgressSimulator || Object.defineProperty(t, "__rocketLoaderLoadProgressSimulator", {
                value: new j
            }), t.__rocketLoaderLoadProgressSimulator
        }(), W = function() {
            function t(t, e) {
                this.scriptStack = t, this.settings = e, this.preloadHints = []
            }
            return t.prototype.insertPreloadHints = function() {
                var t = this;
                this.scriptStack.forEach(function(e) {
                    if (a(e, t.settings.nonce)) {
                        var n = i(e),
                            r = v() && e.hasAttribute("integrity");
                        if (n && !r) {
                            var o = document.createElement("link");
                            o.setAttribute("rel", "preload"), o.setAttribute("as", "script"), o.setAttribute("href", n), e.crossOrigin && o.setAttribute("crossorigin", e.crossOrigin), document.head.appendChild(o), t.preloadHints.push(o)
                        }
                    }
                })
            }, t.prototype.removePreloadHints = function() {
                this.preloadHints.forEach(function(t) {
                    return o(t)
                })
            }, t.prototype.run = function() {
                for (var t = this, e = this; this.scriptStack.hasItems;) {
                    var n = function() {
                        var n = e.settings.docWriteSimulator,
                            r = e.scriptStack.pop();
                        n && !r.async && n.enable(r.placeholder);
                        var o = e.activateScript(r);
                        return o ? r.external && r.executable && !r.async ? (u(o, function() {
                            t.finalizeActivation(r), t.run()
                        }), {
                            value: void 0
                        }) : void e.finalizeActivation(r) : (n && n.flushWrittenContentAndDisable(), "continue")
                    }();
                    if ("object" == typeof n) return n.value
                }
                this.scriptStack.hasItems || this.settings.callback()
            }, t.prototype.finalizeActivation = function(t) {
                this.settings.docWriteSimulator && !t.async && this.settings.docWriteSimulator.flushWrittenContentAndDisable(), M.updateInlineHandlers(), o(t.placeholder)
            }, t.prototype.activateScript = function(t) {
                var n = t.script,
                    r = t.placeholder,
                    o = t.external,
                    i = t.async,
                    a = r.parentNode;
                if (!document.contains(r)) return e("Placeholder for script \n" + n.outerHTML + "\n was detached from document.", "Script will not be executed."), null;
                var c = this.settings.blocking && o && !i ? d(n) : p(n);
                return c ? (a.insertBefore(c, r), c) : (e("Failed to create activatable copy of script \n" + n.outerHTML + "\n", "Script will not be executed."), null)
            }, t
        }(), R = "data-cf-settings", T = "|", B = "data-cf-modified-", U = void 0;
        ! function() {
            var t = document.currentScript;
            if (t) {
                var n = b(t);
                n ? (o(t), g(n), M.updateInlineHandlers(), n.bailout ? w(n.nonce) : (S(), x(n.nonce))) : e("Activator script doesn't have settings. No scripts will be executed.")
            } else e("Can't obtain activator script. No scripts will be executed.")
        }()
    }();
</script>

</body>



</html>