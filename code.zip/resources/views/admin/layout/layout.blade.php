@include('admin.layout.head')



@include('admin.layout.header')



@yield('content')

 

@include('admin.layout.footer')



@stack('js')







  

