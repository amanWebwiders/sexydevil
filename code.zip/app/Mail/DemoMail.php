<?php
  
namespace App\Mail;
  
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
  
class DemoMail extends Mailable
{
    use Queueable, SerializesModels;
  
    public $mailData;
  
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($mailData)
    {
        $this->mailData = $mailData;
    }
  
    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
      
        $return = $this->subject($this->mailData['subject'])
            ->view('email.MailTemp', $this->mailData);

        if (isset($this->mailData['attachments']) && !empty($this->mailData['attachments'])) {
            foreach($this->mailData['attachments'] as $attachment){
                $return->attach($attachment);
            }
            
        }
        return $return;
    }
}